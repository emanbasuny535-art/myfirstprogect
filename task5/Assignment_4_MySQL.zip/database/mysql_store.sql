CREATE DATABASE IF NOT EXISTS mysql_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mysql_store;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
 customer_id INT AUTO_INCREMENT PRIMARY KEY,
 first_name VARCHAR(50) NOT NULL,
 last_name VARCHAR(50) NOT NULL,
 email VARCHAR(100) NOT NULL UNIQUE,
 phone VARCHAR(20),
 city VARCHAR(60) NOT NULL,
 salary DECIMAL(10,2) NOT NULL DEFAULT 0,
 password VARCHAR(255) NULL
);
CREATE TABLE products (
 product_id INT AUTO_INCREMENT PRIMARY KEY,
 product_name VARCHAR(100) NOT NULL,
 unit_price DECIMAL(10,2) NOT NULL
);
CREATE TABLE orders (
 order_id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 order_date DATE NOT NULL,
 FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
CREATE TABLE order_items (
 order_item_id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 product_id INT NOT NULL,
 quantity INT NOT NULL,
 unit_price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(order_id),
 FOREIGN KEY (product_id) REFERENCES products(product_id)
);
CREATE TABLE employees (
 employee_id INT AUTO_INCREMENT PRIMARY KEY,
 employee_name VARCHAR(100) NOT NULL,
 manager_id INT NULL,
 FOREIGN KEY (manager_id) REFERENCES employees(employee_id)
);

INSERT INTO customers(first_name,last_name,email,phone,city,salary) VALUES
('Ahmed','Ali','ahmed@example.com','01010000001','Cairo',35000),
('Tariq','Hassan','tariq@example.com','01010000002','Alexandria',42000),
('Mona','Samir','mona@example.com','01010000003','Cairo',27000),
('Sara','Mahmoud','sara@example.com','01010000004','Giza',18000),
('Omar','Khaled','omar@example.com','01010000005','Alexandria',55000),
('Nour','Adel','nour@example.com','01010000006','Giza',31000),
('Youssef','Mostafa','youssef@example.com','01010000007','Cairo',22000),
('Salma','Fathy','salma@example.com','01010000008','Mansoura',15000);

INSERT INTO products(product_name,unit_price) VALUES
('Milk',125.40),('Orange',729.67),('Coffee',250.00),('Rice',80.00),('Tea',95.00);

INSERT INTO orders(customer_id,order_date) VALUES
(1,'2026-01-02'),(1,'2026-01-10'),(1,'2026-02-01'),
(2,'2026-01-03'),(2,'2026-01-11'),(2,'2026-02-04'),
(3,'2026-01-05'),(3,'2026-02-05'),
(4,'2026-01-06'),(5,'2026-01-07'),(5,'2026-02-07'),
(6,'2026-01-08'),(7,'2026-02-09'),(8,'2026-02-10');

INSERT INTO order_items(order_id,product_id,quantity,unit_price) VALUES
(1,1,50,125.40),(1,2,30,729.67),(2,1,60,125.40),(2,3,20,250),
(3,4,100,80),(4,2,70,729.67),(4,3,40,250),(5,1,80,125.40),
(6,2,50,729.67),(7,3,60,250),(8,4,150,80),(9,5,40,95),
(10,1,90,125.40),(10,2,60,729.67),(11,3,50,250),
(12,4,200,80),(13,5,70,95),(14,1,40,125.40);

INSERT INTO employees(employee_name,manager_id) VALUES ('Mariam Hassan',NULL);
INSERT INTO employees(employee_name,manager_id) VALUES
('Ali Mostafa',1),('Hana Ahmed',1),('Kareem Samy',2),('Laila Omar',2),('Nada Adel',3);
